package quiz_app;

import java.io.IOException;



import java.io.PrintWriter;
import java.sql.*;
import java.sql.DriverManager;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	static Connection con;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
	    String name=request.getParameter("name");
	    String pass=request.getParameter("pass");
	   boolean flag=false;
	
	    try{
	    	Class.forName("com.mysql.jdbc.Driver");
	    	con=DriverManager.getConnection("jdbc:mysql://localhost:3307/quiz","root","admin");
		    Statement st=con.createStatement();
		    ResultSet rs=st.executeQuery("select*from quiz1");
//		    rs.updateString(1,name);
//		    rs.updateString(2, pass);
		   while(rs.next()){
		    	if(name.equals(rs.getString(1))&&pass.equals(rs.getString(2))){
		    	    flag=true; 
		    		out.println("corrrect");
		    		request.getRequestDispatcher("quiz.html").forward(request, response);
		    		break;
		    	}
		   }
		    	if(flag==false){
	    		out.println("invalidate username or password");
	    		request.getRequestDispatcher("login.html").include(request, response);
		           
	        }
	 
	    }catch(Exception e){
				e.printStackTrace();
			}
	}

}
