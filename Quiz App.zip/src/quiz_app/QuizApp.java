package quiz_app;

import java.io.IOException;


import java.io.PrintWriter;
import java.sql.*;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class QuizApp
 */
@WebServlet("/QuizApp")
public class QuizApp extends HttpServlet  {
	static Connection con=null;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QuizApp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		 
	    try
	    {
	    PrintWriter out=response.getWriter();
	    String Ques1=request.getParameter("q1");
	    String Ques2=request.getParameter("q2");
	    String Ques3=request.getParameter("q3");
	    String Ques4=request.getParameter("q4");
	    String Ques5=request.getParameter("q5");
	    String Ques6=request.getParameter("q6");
	    String Ques7=request.getParameter("q7");
	    String Ques8=request.getParameter("q8");
	    String Ques9=request.getParameter("q9");
	    String Ques10=request.getParameter("q10");
	       int count=0;
	      
	       Class.forName("com.mysql.jdbc.Driver");
	       con=DriverManager.getConnection("jdbc:mysql://localhost:3307/question","root","admin");
	       Statement st=con.createStatement();
	      
	       ResultSet rs=st.executeQuery("select *from question1");
	      
	       while(rs.next())
	       {
	        if(Ques1.equals(rs.getString(1)))
	        {
	        count=count+1;
	        }
	        if(Ques2.equals(rs.getString(1)))
	        {
	        count=count+1;
	        }
	        if(Ques3.equals(rs.getString(1)))
	        {
	        count=count+1;
	        }
	        if(Ques4.equals(rs.getString(1)))
	        {
	        count=count+1;
	        }
	        if(Ques5.equals(rs.getString(1)))
	        {
	        count=count+1;
	        }
	        if(Ques6.equals(rs.getString(1)))
	        {
	        count=count+1;
	        }
	        if(Ques7.equals(rs.getString(1)))
	        {
	        count=count+1;
	        }
	        if(Ques8.equals(rs.getString(1)))
	        {
	        count=count+1;
	        }
	        if(Ques9.equals(rs.getString(1)))
	        {
	        count=count+1;
	        }
	        if(Ques10.equals(rs.getString(1)))
	        {
	        count=count+1;
	        } 
	       }
	       
	      out.println("Your Mark Is");
	      out.println(count);
	    }
	    catch(Exception e){
	    	
	            }
	}
}

	

